package com.lm.lawmaster.controller;

import com.lm.lawmaster.entity.Users;
import com.lm.lawmaster.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.*;

//import javax.annotation.Resource;

/**
 * (Users)表控制层
 *
 * @author makejava
 */
@RestController
@RequestMapping("users")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UsersController {
  /**
     * 服务对象
     */
    @Autowired
    private UsersService usersService;

    /**
     * 分页查询
     *
     * @param users       筛选条件
     * @param pageRequest 分页对象
     * @return 查询结果
     */
    @GetMapping
    public ResponseEntity<Page<Users>> queryByPage(Users users, PageRequest pageRequest) {
        return ResponseEntity.ok(this.usersService.queryByPage(users, pageRequest));
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("{id}")
    public ResponseEntity<Users> queryById(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(this.usersService.queryById(id));
    }



    @PostMapping("/login")
    public ResponseEntity<Users> login(@RequestBody Users user) {
        // 查询数据库中是否存在该用户
        Users existingUser = usersService.findByUsername(user.getUsername());
        if (existingUser != null && existingUser.getPassword().equals(user.getPassword())) {
            // 登录成功，返回用户对象
            return ResponseEntity.ok(existingUser);
        } else {
            // 用户名或密码错误
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }
    }

    // ...


    /**
     * 新增数据
     *
     * @param users 实体
     * @return 新增结果
     */
    @PostMapping
    public ResponseEntity<Users> add(@RequestBody Users users) {
        return ResponseEntity.ok(this.usersService.insert(users));
    }

    /**
     * 编辑数据
     *
     * @param users 实体
     * @return 编辑结果
     */
    @PutMapping
    public ResponseEntity<Users> edit(@RequestBody Users users) {
        return ResponseEntity.ok(this.usersService.update(users));
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @DeleteMapping
    public ResponseEntity<Boolean> deleteById(Integer id) {
        return ResponseEntity.ok(this.usersService.deleteById(id));
    }
//    Register function
    @PostMapping("/register")
    public ResponseEntity<Users> register(@RequestBody Users user) {
        // 查询数据库中是否存在该用户
        Users existingUser = usersService.findByUsername(user.getUsername());
        if (existingUser != null) {
            // 用户名已存在
            return ResponseEntity.status(HttpStatus.CONFLICT).body(null);
        } else {
            // 注册成功，返回用户对象
            return ResponseEntity.ok(usersService.insert(user));
        }
    }
    
}

