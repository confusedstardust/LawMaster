package com.lm.lawmaster.controller;

import com.lm.lawmaster.entity.Posts;
import com.lm.lawmaster.service.PostsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("files")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class FileController {

    @Autowired
    private PostsService postsService;

    @GetMapping("/download/{imageName}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String imageName) {
        try {
            // 加载资源文件，使用 ClassPathResource
            Resource resource = new ClassPathResource("static/files/" + imageName); // 假设文件位于 resources/static 目录下

            // 确保文件存在
            if (resource.exists()) {
                // 获取文件类型，如果无法获取，默认使用 application/octet-stream
                String contentType = Files.probeContentType(Paths.get(resource.getURI()));
                if (contentType == null) {
                    contentType = "application/octet-stream";
                }

                return ResponseEntity.ok()
                        .contentType(MediaType.parseMediaType(contentType))
                        .body(resource);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }



//    @GetMapping("/posts")
//    public ResponseEntity<Page<Posts>> queryByPage(
//            @RequestParam(defaultValue = "0") int page,
//            @RequestParam(defaultValue = "10") int size) {
//
//        Pageable pageable = PageRequest.of(page, size);
//        Page<Posts> postsPage = postsService.findAll(pageable);
//        return ResponseEntity.ok(postsPage);
//    }


}
