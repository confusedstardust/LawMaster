package com.lm.lawmaster.service.impl;

import com.lm.lawmaster.entity.Posts;
import com.lm.lawmaster.dao.PostsDao;
import com.lm.lawmaster.service.PostsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.List;

//import javax.annotation.Resource;

/**
 * (Posts)表服务实现类
 *
 * @author makejava
 */
@Service("postsService")
public class PostsServiceImpl implements PostsService {
    @Autowired
    private PostsDao postsDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public Posts queryById(Integer id) {
        return this.postsDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param posts       筛选条件
     * @param pageRequest 分页对象
     * @return 查询结果
     */
    @Override
    public Page<Posts> queryByPage(Posts posts, PageRequest pageRequest) {
        long total = this.postsDao.count(posts);
        return new PageImpl<>(this.postsDao.queryAllByLimit(posts, pageRequest), pageRequest, total);
    }



    /**
     * 新增数据
     *
     * @param posts 实例对象
     * @return 实例对象
     */
    @Override
    public Posts insert(Posts posts) {
        this.postsDao.insert(posts);
        return posts;
    }

    /**
     * 修改数据
     *
     * @param posts 实例对象
     * @return 实例对象
     */
    @Override
    public Posts update(Posts posts) {
        this.postsDao.update(posts);
        return this.queryById(posts.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Integer id) {
        return this.postsDao.deleteById(id) > 0;
    }


    @Override
    public List<Posts> queryAll() {
        return this.postsDao.queryAll();
    }

    public List<Posts> queryByTag(String tag) {
        return this.postsDao.queryByTag(tag);
    }

    //    query posts by post id, reveive an array of post id
    public List<Posts> queryByPostIds(List<Integer> postId) {
        return this.postsDao.queryByPostIds(postId);
    }
}
